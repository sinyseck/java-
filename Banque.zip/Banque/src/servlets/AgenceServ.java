package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Agence;
import dao.AgenceDaoImpl;

import java.util.ArrayList;
import java.util.List;
 

/**
 * Servlet implementation class AgenceServ
 */
@WebServlet("/AgenceServ")
public class AgenceServ extends HttpServlet {
	private AgenceDaoImpl adi;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AgenceServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		adi = new AgenceDaoImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
				//Suppression
				if(request.getParameter("id") != null)
				{
					int id = Integer.parseInt(request.getParameter("id").toString());
					int ok = 0;
					PrintWriter s = response.getWriter();
					s.println(id);
					try {
						ok = adi.deleteAgence(id);
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					java.util.List<Agence> liste = new ArrayList<Agence>();
					liste = adi.listAgence();
					request.setAttribute("listeA", liste);
					request.getRequestDispatcher("/view/agence/liste.jsp")
							.forward(request, response);
					
				}
				
				//Modification
				if(request.getParameter("idm") != null)
				{
					int id = Integer.parseInt(request.getParameter("idm").toString());
				
					
					Agence ag  = new Agence();
					ag = adi.getAgenceById(id);
					request.setAttribute("agence", ag);
					request.getRequestDispatcher("/view/agence/update.jsp")
							.forward(request, response);
				
				}
				
				if(request.getParameter("choix") != null)
				{
					switch(request.getParameter("choix").toString().charAt(0))
					{
						case 'a':
								request.getRequestDispatcher("/view/agence/add.jsp")
												.forward(request, response);
							break;
						case 'l':
								java.util.List<Agence> liste = new ArrayList<Agence>();
								liste = adi.listAgence();
								request.setAttribute("listeA", liste);
							
								request.getRequestDispatcher("/view/agence/liste.jsp")
												.forward(request, response);
							break;
						default:
							
							break;
					}
				}
				
				
				
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		
		if(request.getParameter("envoyer")!= null)
		{
			
	
			String numAgence = request.getParameter("numAgence").toString();
			String nom = request.getParameter("nom").toString();
			String adresse = request.getParameter("adresse").toString();
			Agence  a= new Agence(1,numAgence,nom,adresse);
			int ok = 0;
			try
			{
				ok = adi.addAgence(a);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			if(ok != 0)
				request.setAttribute("ok", "1");		
			else	
				request.setAttribute("ok", "0");
			
			request.getRequestDispatcher("/view/agence/add.jsp")
			.forward(request, response);
			
	
	
	
		}
		if(request.getParameter("modifier") != null)
		{
			int id = Integer.parseInt(request.getParameter("id"));
			String numAgence = request.getParameter("numAgence").toString();
			String nom = request.getParameter("nom").toString();
			String adresse = request.getParameter("adresse").toString();
			Agence a  = new Agence(id,numAgence,nom,adresse);
			adi.updateAgence(a);
			java.util.List<Agence> liste = new ArrayList<Agence>();
			liste = adi.listAgence();
			request.setAttribute("listeA", liste);
		
			request.getRequestDispatcher("/view/agence/liste.jsp")
							.forward(request, response);
			
			
		}
	}
}

