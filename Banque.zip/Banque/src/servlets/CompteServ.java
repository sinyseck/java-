package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AgenceDaoImpl;
import dao.ClientDaoImpl;
import dao.CompteEpargneImpl;
import dao.CompteDaoImpl;
import beans.Agence;
import beans.Client;
import beans.Compte;
import beans.CompteEpargne;
import beans.CompteModel;


/**
 * Servlet implementation class CompteServ
 */
@WebServlet("/CompteServ")
public class CompteServ extends HttpServlet {
	private CompteDaoImpl cdi;
	private AgenceDaoImpl adi;
	private ClientDaoImpl cldi;
	private CompteEpargneImpl cei;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CompteServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		cdi = new CompteDaoImpl();
		adi = new AgenceDaoImpl();
		cldi = new ClientDaoImpl();
		cei = new CompteEpargneImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Suppression
				if(request.getParameter("id") != null)
				{
					int id = Integer.parseInt(request.getParameter("id").toString());
					int ok = 0;
					PrintWriter s = response.getWriter();
					s.println(id);
					try {
						ok = cdi.deleteCompte(id);
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					java.util.List<Compte> liste = new ArrayList<Compte>();
					liste = cdi.listCompte();
					request.setAttribute("listeC", liste);
					request.getRequestDispatcher("/view/compte/liste.jsp")
							.forward(request, response);
					
				}
		
		List<Agence> listeAgence = new ArrayList<Agence>();
		listeAgence = adi.listAgence();
		request.setAttribute("listeA", listeAgence);
		
		List<Client> listeClient = new ArrayList<Client>();
		listeClient = cldi.listClient();
		request.setAttribute("listeC", listeClient);
		
		if(request.getParameter("choix") != null)
		{
			switch(request.getParameter("choix").toString().charAt(0))
			{
				case 'a':
						request.getRequestDispatcher("/view/compte/add.jsp")
										.forward(request, response);
					break;
				case 'l':
						java.util.List<Compte> liste = new ArrayList<Compte>();
						liste = cdi.listCompte();
						request.setAttribute("listeC", liste);
					
						request.getRequestDispatcher("/view/compte/liste.jsp")
										.forward(request, response);
					break;
				default:
					
					break;
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		if(request.getParameter("envoyer")!= null)
		{
			String agence = request.getParameter("agence").toString();
			Agence a = new Agence();
			a.setNumAgence(agence);
			String numCompte = request.getParameter("numCompte").toString();
			String cleRib = request.getParameter("cleRib").toString();
			String dateCreation = (request.getParameter("date"));

			double solde = Double.parseDouble(request.getParameter("solde"));
			String client = request.getParameter("client").toString();
			Client c = new Client();
			c.setCode(client);
			String typeC = request.getParameter("btn").toString();
			Compte cpte= new Compte (0,a,numCompte,cleRib,dateCreation,solde,c,typeC);
			
			
			int ok = 0;
			try
			{
				ok = cdi.addCompte(cpte);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			if(ok != 0)
				request.setAttribute("ok", "1");		
			else	
				request.setAttribute("ok", "0");
			
			List<Agence> listeAgence = new ArrayList<Agence>();
			listeAgence = adi.listAgence();
			request.setAttribute("listeA", listeAgence);
			
			List<Client> listeClient = new ArrayList<Client>();
			listeClient = cldi.listClient();
			request.setAttribute("listeC", listeClient);
			
			request.getRequestDispatcher("/view/compte/add.jsp")
			.forward(request, response);
			
	
	
	
		}
	}

}
