package servlets;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RootServ
 */
@WebServlet("/RootServ")
public class RootServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RootServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("page") != null)
		{
			switch(request.getParameter("page").toString().charAt(0))
			{
			case 'a':
					request.getRequestDispatcher("/view/agence/index.jsp")
						.forward(request, response);
				break;
			case 'A':
				request.getRequestDispatcher("/view/agence/liste.jsp")
					.forward(request, response);
			break;
			case 'e':
					request.getRequestDispatcher("/view/employe/index.jsp")
						.forward(request, response);
				break;
			case 'c':
					request.getRequestDispatcher("/view/client/index.jsp")
						.forward(request, response);
				break;
			case 'C':
				request.getRequestDispatcher("/view/compte/index.jsp")
					.forward(request, response);
			break;
			case 'i':
				request.getRequestDispatcher("/indexee.jsp")
					.forward(request, response);
			break;
			case 'u':
				request.getRequestDispatcher("/indexe.jsp")
					.forward(request, response);
			break;
			case 'g':
				request.getRequestDispatcher("/comptes.jsp")
					.forward(request, response);
			break;
			case 'o':
				request.getRequestDispatcher("/view/operation/index.jsp")
					.forward(request, response);
			break;
			case 'O':
				request.getRequestDispatcher("/view/operation/indexe.jsp")
					.forward(request, response);
			break;case 's':
				request.getRequestDispatcher("/comptee.jsp")
				.forward(request, response);
		break;
			
			default:
				
				break;
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
