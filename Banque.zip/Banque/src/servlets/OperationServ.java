package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CompteDaoImpl;
import dao.OperationDaoImpl;
import beans.Agence;
import beans.Client;
import beans.Compte;
import beans.Operation;

/**
 * Servlet implementation class OperationServ
 */
@WebServlet("/OperationServ")
public class OperationServ extends HttpServlet {
	private OperationDaoImpl odi;
	private CompteDaoImpl cdi;

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OperationServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		cdi = new CompteDaoImpl();
		odi = new OperationDaoImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Suppression
				if(request.getParameter("id") != null)
				{
					int id = Integer.parseInt(request.getParameter("id").toString());
					int ok = 0;
					PrintWriter s = response.getWriter();
					s.println(id);
					try {
						ok = odi.deleteOperation(id);
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					java.util.List<Operation> liste = new ArrayList<Operation>();
					liste = odi.listOperation();
					request.setAttribute("listeO", liste);
					request.getRequestDispatcher("/view/operation/liste.jsp")
							.forward(request, response);
					
				}
		
				List<Compte> listeCompte = new ArrayList<Compte>();
				listeCompte = cdi.listCompte();
				request.setAttribute("listeC", listeCompte);
				
				if(request.getParameter("choix") != null)
				{
					switch(request.getParameter("choix").toString().charAt(0))
					{
						case 'a':
								request.getRequestDispatcher("/view/operation/add.jsp")
												.forward(request, response);
							break;
							
						case 'A':
							request.getRequestDispatcher("/view/operation/add2.jsp")
											.forward(request, response);
						break;
						case 'l':
								java.util.List<Operation> liste = new ArrayList<Operation>();
								liste = odi.listOperation();
								request.setAttribute("listeO", liste);
							
								request.getRequestDispatcher("/view/operation/liste.jsp")
												.forward(request, response);
							break;
						case 'L':
							java.util.List<Operation> liste2 = new ArrayList<Operation>();
							liste2 = odi.listOperation();
							request.setAttribute("listeO", liste2);
						
							request.getRequestDispatcher("/view/operation/liste2.jsp")
											.forward(request, response);
						break;
						default:
							
							break;
					}
		}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("envoyer")!= null)
		{
			String numero = request.getParameter("numero").toString();
			String type = request.getParameter("type").toString();
			String dateOperation = (request.getParameter("date"));
			double montant = Double.parseDouble(request.getParameter("montant"));
			String compte = request.getParameter("compte").toString();
			Compte c = new Compte();
			c.setNumCompte(compte);
			Operation op= new Operation(0,numero,type,dateOperation,montant,c);
			
			
			int ok = 0;
			try
			{
				ok = odi.addOperation(op);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			if(ok != 0)
				request.setAttribute("ok", "1");		
			else	
				request.setAttribute("ok", "0");
			
			
			
			List<Compte> listeCompte = new ArrayList<Compte>();
			listeCompte = cdi.listCompte();
			request.setAttribute("listeC", listeCompte);
			
			request.getRequestDispatcher("/view/operation/add.jsp")
			.forward(request, response);
			
	
	
	
		}
	}

}
