package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ClientDaoImpl;
import beans.Client;

/**
 * Servlet implementation class ClientServ
 */
@WebServlet("/ClientServ")
public class ClientServ extends HttpServlet {
	private ClientDaoImpl idi;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClientServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		idi = new ClientDaoImpl();
		}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Suppression
		if(request.getParameter("id") != null)
		{
			int id = Integer.parseInt(request.getParameter("id").toString());
			int ok = 0;
			PrintWriter s = response.getWriter();
			s.println(id);
			try {
				ok = idi.deleteClient(id);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			java.util.List<Client> liste = new ArrayList<Client>();
			liste = idi.listClient();
			request.setAttribute("listeC", liste);
			request.getRequestDispatcher("/view/client/liste.jsp")
					.forward(request, response);
			
		}
		
		
		if(request.getParameter("choix") != null)
		{
			switch(request.getParameter("choix").toString().charAt(0))
			{
				case 'a':
						request.getRequestDispatcher("/view/client/add.jsp")
										.forward(request, response);
					break;
				case 'l':
						java.util.List<Client> liste = new ArrayList<Client>();
						liste = idi.listClient();
						request.setAttribute("listeC", liste);
					
						request.getRequestDispatcher("/view/client/liste.jsp")
										.forward(request, response);
					break;
				default:
					
					break;
			}
		}
		
		if(request.getParameter("idm") != null)
		{
			int id = Integer.parseInt(request.getParameter("idm").toString());
		
			
			Client cl  = new Client();
			cl = idi.getClientById(id);
			request.setAttribute("client", cl);
			request.getRequestDispatcher("/view/client/update.jsp")
					.forward(request, response);
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("envoyer")!= null)
		{
			
	
			String code = request.getParameter("code").toString();
			String nom = request.getParameter("nom").toString();
			String prenom = request.getParameter("prenom").toString();
			String dateNais = request.getParameter("dateNais").toString();
			String ville = request.getParameter("ville").toString();
			String pays = request.getParameter("pays").toString();
			String mail = request.getParameter("mail").toString();
			String telephone = request.getParameter("telephone").toString();
			String profession = request.getParameter("profession").toString();
			String travailleur = request.getParameter("btn").toString();
			String salaire = request.getParameter("salaire").toString();
			String employeur = request.getParameter("employeur").toString();
			String motDePasse = request.getParameter("motDePasse").toString();
			String solde = request.getParameter("solde").toString();
			String agence = request.getParameter("agence").toString();




			Client  cl= new Client(0,code,nom,prenom,dateNais,ville,pays,mail,telephone,profession,travailleur,salaire,employeur,motDePasse,solde,agence);
			int ok = 0;
			try
			{
				ok = idi.addClient(cl);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			if(ok != 0)
				request.setAttribute("ok", "1");		
			else	
				request.setAttribute("ok", "0");
			
			request.getRequestDispatcher("/view/client/add.jsp")
			.forward(request, response);
			
	
	
	
		}
		
		if(request.getParameter("modifier") != null)
		{
			int id = Integer.parseInt(request.getParameter("id"));
			String code = request.getParameter("code").toString();
			String nom = request.getParameter("nom").toString();
			String prenom = request.getParameter("prenom").toString();
			String dateNais = request.getParameter("dateNais").toString();
			String ville = request.getParameter("ville").toString();
			String pays = request.getParameter("pays").toString();
			String mail = request.getParameter("mail").toString();
			String telephone = request.getParameter("telephone").toString();
			String profession = request.getParameter("profession").toString();
			String travailleur = request.getParameter("travailleur").toString();
			String salaire = request.getParameter("salaire").toString();
			String employeur = request.getParameter("employeur").toString();
			String motDePasse = request.getParameter("motDePasse").toString();
			String solde = request.getParameter("solde").toString();
			String agence = request.getParameter("agence").toString();

			Client  cl= new Client(1,code,nom,prenom,dateNais,ville,pays,mail,telephone,profession,travailleur,salaire,employeur,motDePasse,solde,agence);
			idi.updateClient(cl);
			java.util.List<Client> liste = new ArrayList<Client>();
			liste = idi.listClient();
			request.setAttribute("listeC", liste);
		
			request.getRequestDispatcher("/view/client/liste.jsp")
							.forward(request, response);
			
			
		}
	}

}
