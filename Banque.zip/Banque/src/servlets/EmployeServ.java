package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AgenceDaoImpl;
import dao.EmployeDaoImpl;
import beans.Agence;
import beans.Employe;

/**
 * Servlet implementation class EmployeServ
 */
@WebServlet("/EmployeServ")
public class EmployeServ extends HttpServlet {
	private EmployeDaoImpl edi;
	private AgenceDaoImpl adi;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		edi = new EmployeDaoImpl();
		adi = new AgenceDaoImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if(request.getParameter("id") != null)
		{
			int id = Integer.parseInt(request.getParameter("id").toString());
			int ok = 0;
			PrintWriter s = response.getWriter();
			s.println(id);
			try {
				ok = edi.deleteEmploye(id);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			java.util.List<Employe> liste = new ArrayList<Employe>();
			liste = edi.listEmploye();
			request.setAttribute("listeE", liste);
			request.getRequestDispatcher("/view/employe/liste.jsp")
					.forward(request, response);
			
		}
		
		
		
		
			//Modification
			if(request.getParameter("idm") != null)
			{
				int id = Integer.parseInt(request.getParameter("idm").toString());
			
				
				Employe em  = new Employe();
				em = edi.getEmployeById(id);
				request.setAttribute("employe", em);
				request.getRequestDispatcher("/view/employe/update.jsp")
						.forward(request, response);
		
			}
		
		
		List<Agence> listeAgence = new ArrayList<Agence>();
		listeAgence = adi.listAgence();
		request.setAttribute("listeA", listeAgence);
		
		if(request.getParameter("choix") != null)
		{
			switch(request.getParameter("choix").toString().charAt(0))
			{
				case 'a':
						request.getRequestDispatcher("/view/employe/add.jsp")
										.forward(request, response);
					break;
				case 'l':
						java.util.List<Employe> liste = new ArrayList<Employe>();
						liste = edi.listEmploye();
						request.setAttribute("listeE", liste);
					
						request.getRequestDispatcher("/view/employe/liste.jsp")
										.forward(request, response);
					break;
				default:
					
					break;
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("envoyer")!= null)
		{
			
	
			String code = request.getParameter("code").toString();
			String nom = request.getParameter("nom").toString();
			String prenom = request.getParameter("prenom").toString();
			String poste = request.getParameter("poste").toString();
			String telephone = request.getParameter("tel").toString();
			
			int agence = Integer.parseInt(request.getParameter("agence"));
			
			Agence a = new Agence();
			a.setIdA(agence);
			
			Employe  em= new Employe(0,code,nom,prenom,poste,telephone,a);
			int ok = 0;
			try
			{
				ok = edi.addEmploye(em);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			if(ok != 0)
				request.setAttribute("ok", "1");		
			else	
				request.setAttribute("ok", "0");
			
			List<Agence> listeAgence = new ArrayList<Agence>();
			listeAgence = adi.listAgence();
			request.setAttribute("listeA", listeAgence);
			
			request.getRequestDispatcher("/view/employe/add.jsp")
			.forward(request, response);
			
	
	
	
		}
		
		if(request.getParameter("modifier") != null)
		{
			
			String code = request.getParameter("code").toString();
			String nom = request.getParameter("nom").toString();
			String prenom = request.getParameter("prenom").toString();
			String poste = request.getParameter("poste").toString();
			String telephone = request.getParameter("tel").toString();
			int idA = Integer.parseInt(request.getParameter("agence"));
			
			Agence ag = new Agence();
			ag.setIdA(idA);
			
			Employe  em= new Employe(0,code,nom,prenom,poste,telephone,ag);
			edi.updateEmploye(em);
			java.util.List<Employe> liste = new ArrayList<Employe>();
			liste = edi.listEmploye();
			List<Agence> listeAgence = new ArrayList<Agence>();
			listeAgence = adi.listAgence();
			request.setAttribute("listeA", listeAgence);
		
			request.getRequestDispatcher("/view/employe/liste.jsp")
							.forward(request, response);
			
			
		}
	}

}
