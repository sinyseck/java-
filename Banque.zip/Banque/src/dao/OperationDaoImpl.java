package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import beans.Operation;
import beans.Agence;
import beans.Client;
import beans.Compte;

public class OperationDaoImpl implements OperationDao{
	private int ok;
	private ResultSet rs;
	private DB db;
	private PreparedStatement pstm;
	
	@Override
	public int addOperation(Operation o) {
		String sql="insert into operation values(null,?,?,?,?,?)";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setString(1, o.getNumero());
			db.getPstm().setString(2, o.getType());
			db.getPstm().setString(3, o.getDateOperation());
			db.getPstm().setDouble(4, o.getMontant());
			db.getPstm().setString(5, o.getCompte().getNumCompte());
			
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;

	}
	@Override
	public int deleteOperation(int id) {
		String sql = "delete from operation where idO = ?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setInt(1, id);
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}
	@Override
	public int updateOperation(Operation o) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public List<Operation> listOperation() {
		db = new DB();
		String sql = "select * from operation";
		List<Operation> liste = new ArrayList<Operation>();
		try
		{
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			while(rs.next())
			{
				Operation o = new Operation();
				o.setIdO(rs.getInt(1));
				o.setNumero(rs.getString(2));
				o.setType(rs.getString(3));
				o.setDateOperation(rs.getString(4));
				o.setMontant(rs.getDouble(5));
				Compte c = new Compte();
				c.setNumCompte(rs.getString(6));
				o.setCompte(c);
				
				
				liste.add(o);
				
				
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return liste;
	}
	@Override
	public Operation getOperationeById(int idO) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
