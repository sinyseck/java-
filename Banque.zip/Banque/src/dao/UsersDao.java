package dao;

import beans.Users;

public interface UsersDao {
	public int connexionU(Users us);

}
