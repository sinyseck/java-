package dao;

import java.util.List;

import beans.CompteEpargne;

public interface CompteEpargneDao {
	public int addCompteE(CompteEpargne ce);
	public int  deleteCompteE(int id);
	public int updateCompteE(CompteEpargne ce);
	public List<CompteEpargne> listCompteE();
	public 	CompteEpargne getCompteEById(int idCE);

}
