package dao;

import beans.User;

public interface UserDao {
	public int connexionU(User us);

}
