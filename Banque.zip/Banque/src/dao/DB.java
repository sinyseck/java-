
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author 
 */
public class DB {
	
    private Connection con=null;
    private Statement stm=null;
    private PreparedStatement pstm;
	private ResultSet rs=null;
    private int ok=0;
    
    public PreparedStatement getPstm() {
		return pstm;
	}


	public DB(){}
    
    public void ouvrirConnexion()
    {
        String url="jdbc:mysql://localhost:8889/banque";
        try{
            if(con==null||con.isClosed())
            {
                Class.forName("com.mysql.jdbc.Driver");
                con=DriverManager.getConnection(url, "root","root");
               // System.out.print("connexion ok");
            }
        } catch(Exception Ex){
            Ex.printStackTrace();
        }
    }
    
    
    
    public void initPrepareStatement(String sql)
    {
    	ouvrirConnexion();
        try{
           pstm=con.prepareStatement(sql); 
        }catch(Exception Ex){
            Ex.printStackTrace();
        }
    }
    
    
    
    public int executeMAJ()
    {
        ouvrirConnexion();
        try{
           ok=pstm.executeUpdate();   
        }catch(Exception Ex){
            Ex.printStackTrace();
        }
        return ok;
    }
    
    
    
    public ResultSet executeSelect()
    {
        try{
            rs=pstm.executeQuery();
        }catch(Exception Ex){
         Ex.printStackTrace();
    }
        return rs;
    }
    
    
    public void fermeConnexion() 
    {
        try{
        stm.close();
        rs.close();
        }catch(Exception Ex){
            Ex.printStackTrace();
        }
    }

   
}
