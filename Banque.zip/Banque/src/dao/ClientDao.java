package dao;

import java.util.List;

import beans.Client;

public interface ClientDao {
	public int addClient(Client cl);
	public int  deleteClient(int id);
	public int updateClient(Client cl);
	public List<Client> listClient();
	public Client getClientById(int idC);

}
