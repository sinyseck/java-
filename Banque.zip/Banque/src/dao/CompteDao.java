package dao;

import java.util.List;

import beans.Compte;

public interface CompteDao {
	public int addCompte(Compte c);
	public int deleteCompte(int id);
	public int updateCompte(Compte c);
	public List<Compte> listCompte();
	public Compte getCompte(String numCompte);
	public List<Compte> comptesparMC(String mc);
}
