package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Agence;


public class AgenceDaoImpl implements AgenceDao{
	private int ok;
	private ResultSet rs;
	private DB db;
	private PreparedStatement pstm;

	@Override
	public int addAgence(Agence a) {
		String sql="insert into agence values(null,?,?,?)";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setString(1, a.getNumAgence());
			db.getPstm().setString(2, a.getNom());
			db.getPstm().setString(3, a.getAdresse());
			
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;

	}

	@Override
	public int deleteAgence(int id) {
		String sql = "delete from agence where idA = ?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setInt(1, id);
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

	@Override
	public int updateAgence(Agence a) {
		String sql = "update agence set numAgence=? set nom=? set adresse=? where idA= ?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			
			db.getPstm().setString(1, a.getNumAgence());
			db.getPstm().setString(2, a.getNom());
			db.getPstm().setString(3, a.getAdresse());
		
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

	@Override
	public List<Agence> listAgence() {
		db = new DB();
		String sql = "select * from agence";
		List<Agence> liste = new ArrayList<Agence>();
		try
		{
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			while(rs.next())
			{
				Agence ag = new Agence();
				ag.setIdA(rs.getInt(1));
				ag.setNumAgence(rs.getString(2));
				ag.setNom(rs.getString(3));
				ag.setAdresse(rs.getString(4));
				
				liste.add(ag);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return liste;
	}

	@Override
	public Agence getAgenceById(int idA) 
	{
		String sql = "select * from agence where idA= "+idA ;
		Agence ag = new Agence();
		try
		{
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			if(rs.next())
			{
				ag = new Agence();
				ag.setIdA(rs.getInt(1));
				ag.setNumAgence(rs.getString(2));
				ag.setNom(rs.getString(3));
				ag.setAdresse(rs.getString(4));
				
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ag;
	}

	@Override
	public Agence getAgenceById(String mc) {
		String sql = "select * from agence where nom like?" ;
		Agence ag = new Agence();
		try
		{
			pstm.setString(1, "%"+mc+"%");

			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			if(rs.next())
			{
				ag = new Agence();
				ag.setIdA(rs.getInt(1));
				ag.setNumAgence(rs.getString(2));
				ag.setNom(rs.getString(3));
				ag.setAdresse(rs.getString(4));
				
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ag;

		
		
}
	
}
	

	


