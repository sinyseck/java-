package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import beans.Users;

public class UsersDaoImpl implements UsersDao{
	private int ok;
	private ResultSet rs;
	private DB db;
	private PreparedStatement pstm;

	@Override
	public int connexionU(Users us) {
		String sql="select * from users where username=? and password=?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setString(1, us.getUsername());
			db.getPstm().setString(2, us.getPassword());
			
			
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

	}


