package dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import beans.Client;


public class ClientDaoImpl implements ClientDao{
	private int ok;
	private ResultSet rs;
	private DB db;
	@Override
	
	public int addClient(Client cl) {
		String sql="insert into client values(null,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setString(1, cl.getCode());
			db.getPstm().setString(2, cl.getNom());
			db.getPstm().setString(3, cl.getPrenom());
			db.getPstm().setString(4, cl.getDateNais());
			db.getPstm().setString(5, cl.getVille());
			db.getPstm().setString(6, cl.getPays());
			db.getPstm().setString(7, cl.getMail());
			db.getPstm().setString(8, cl.getTelephone());
			db.getPstm().setString(9, cl.getProfession());
			db.getPstm().setString(10, cl.getTravailleur());
			db.getPstm().setString(11, cl.getSalaire());
			db.getPstm().setString(12, cl.getEmployeur());
			db.getPstm().setString(13, cl.getMotDePasse());
			db.getPstm().setString(14, cl.getSolde());
			db.getPstm().setString(15, cl.getAgence());




			


			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

	@Override
	public int deleteClient(int id) {
		String sql = "delete from client where id = ?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setInt(1, id);
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
		
	}

	@Override
	public int updateClient(Client cl) {
		String sql = "update client set nom=? where id = ?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setInt(1, cl.getId());
			db.getPstm().setString(2, cl.getCode());
			db.getPstm().setString(3, cl.getNom());
			db.getPstm().setString(4, cl.getPrenom());
			db.getPstm().setString(5, cl.getDateNais());
			db.getPstm().setString(6, cl.getVille());
			db.getPstm().setString(7, cl.getPays());
			db.getPstm().setString(8, cl.getMail());
			db.getPstm().setString(8, cl.getTelephone());
			db.getPstm().setString(10, cl.getProfession());
			db.getPstm().setString(11, cl.getTravailleur());
			db.getPstm().setString(12, cl.getSalaire());
			db.getPstm().setString(13, cl.getEmployeur());
			db.getPstm().setString(14, cl.getMotDePasse());
			db.getPstm().setString(15, cl.getSolde());
			db.getPstm().setString(16, cl.getAgence());

			
			
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

	@Override
	public List<Client> listClient() {
		db = new DB();
		String sql = "select * from client";
		List<Client> liste = new ArrayList<Client>();
		try
		{
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			while(rs.next())
			{
				Client c = new Client();
				c.setId(rs.getInt(1));
				c.setCode(rs.getString(2));
				c.setNom(rs.getString(3));
				c.setPrenom(rs.getString(4));
				c.setDateNais(rs.getString(5));
				c.setVille(rs.getString(6));
				c.setPays(rs.getString(7));
				c.setMail(rs.getString(8));
				c.setTelephone(rs.getString(9));
				c.setProfession(rs.getString(10));
				c.setTravailleur(rs.getString(11));
				c.setSalaire(rs.getString(12));
				c.setTravailleur(rs.getString(11));
				c.setSalaire(rs.getString(12));
				c.setEmployeur(rs.getString(13));
				c.setMotDePasse(rs.getString(14));
				c.setSolde(rs.getString(15));
				c.setAgence(rs.getString(16));

				
				liste.add(c);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return liste;
	}

	@Override
	public Client getClientById(int idC) 
	{
		String sql = "select * from client where idC= "+idC ;
		Client cl= new Client();
		try
		{
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			if(rs.next())
			{
				cl = new Client();
				cl.setId(rs.getInt(1));
				cl.setCode(rs.getString(2));
				cl.setNom(rs.getString(3));
				cl.setPrenom(rs.getString(4));
				cl.setDateNais(rs.getString(5));
				cl.setVille(rs.getString(6));
				cl.setPays(rs.getString(7));
				cl.setMail(rs.getString(8));
				cl.setTelephone(rs.getString(9));
				cl.setProfession(rs.getString(10));
				cl.setTravailleur(rs.getString(11));
				cl.setSalaire(rs.getString(12));
				cl.setTravailleur(rs.getString(11));
				cl.setSalaire(rs.getString(12));
				cl.setEmployeur(rs.getString(13));
				cl.setMotDePasse(rs.getString(14));
				cl.setSolde(rs.getString(15));
				cl.setAgence(rs.getString(16));				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return cl;

	}

	

	
	}


