package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import beans.User;

public class UserDaoImpl implements UserDao {
	private int ok;
	private ResultSet rs;
	private DB db;
	private PreparedStatement pstm;

	@Override
	public int connexionU(User us) {
		String sql="select * from user where username=? and password=?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setString(1, us.getUsername());
			db.getPstm().setString(2, us.getPassword());
			
			
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

}
