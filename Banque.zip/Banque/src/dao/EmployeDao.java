package dao;

import java.util.List;

import beans.Employe;

public interface EmployeDao {
	public int addEmploye(Employe em);
	public int deleteEmploye(int id);
	public int updateEmploye(Employe em);
	public List<Employe> listEmploye();
	public Employe getEmployeById(int idE);

}
