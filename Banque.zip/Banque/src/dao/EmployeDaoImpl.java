package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import beans.Employe;
import beans.Agence;

public class EmployeDaoImpl implements EmployeDao{
	private int ok;
	private ResultSet rs;
	private DB db;
	private PreparedStatement pstm;

	@Override
	public int addEmploye(Employe em) {
		String sql="insert into employe values(null,?,?,?,?,?,?)";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setString(1, em.getCode());
			db.getPstm().setString(2, em.getNom());
			db.getPstm().setString(3, em.getPrenom());
			db.getPstm().setString(4, em.getPoste());
			db.getPstm().setString(5, em.getTel());
			db.getPstm().setInt(6, em.getIdA().getIdA());
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

	@Override
	public int deleteEmploye(int id) {
		String sql = "delete from employe where idE = ?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setInt(1, id);
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

	@Override
	public int updateEmploye(Employe em) {
		String sql = "update employe set code=? set nom=? set prenom=? set poste=? set tel=? set idA=? where idE= ?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			
			db.getPstm().setString(1, em.getCode());
			db.getPstm().setString(2, em.getNom());
			db.getPstm().setString(3, em.getPrenom());
			db.getPstm().setString(4, em.getPoste());
			db.getPstm().setString(5, em.getTel());
			db.getPstm().setInt(6, em.getIdA().getIdA());
		
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}
	

	@Override
	public List<Employe> listEmploye() {
		db = new DB();
		String sql = "select * from employe";
		List<Employe> liste = new ArrayList<Employe>();
		try
		{
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			while(rs.next())
			{
				Employe em= new Employe();
				em.setIdE(rs.getInt(1));
				em.setCode(rs.getString(2));
				em.setNom(rs.getString(3));
				em.setPrenom(rs.getString(4));
				em.setPoste(rs.getString(5));
				em.setTel(rs.getString(6));
				
				Agence ag = new Agence();
				ag.setIdA(rs.getInt(7));
				em.setAgence(ag);
				
				liste.add(em);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return liste;
	}

	@Override
	public Employe getEmployeById(int idE) {
		String sql = "select * from employe where idE= "+idE ;
		Employe em = new Employe();
		try
		{
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			if(rs.next())
			{
				em = new Employe();
				em.setIdE(rs.getInt(1));
				em.setCode(rs.getString(2));
				em.setNom(rs.getString(3));
				em.setPrenom(rs.getString(4));
				em.setPoste(rs.getString(5));
				em.setTel(rs.getString(6));
				
				Agence ag = new Agence();
				ag.setIdA(rs.getInt(7));
				
				em.setAgence(ag);
				
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return em;
	}
	

}
