package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import beans.Agence;
import beans.Client;
import beans.Compte;

public class CompteDaoImpl implements CompteDao{
	private int ok;
	private ResultSet rs;
	private DB db;
	private PreparedStatement pstm;

	@Override
	public int addCompte(Compte c) {
		String sql="insert into compte values(null,?,?,?,?,?,?,?)";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setString(1, c.getAgence().getNumAgence());
			db.getPstm().setString(2, c.getNumCompte());
			db.getPstm().setString(3, c.getCleRib());
			db.getPstm().setString(4, c.getDateCreation());
			db.getPstm().setDouble(5, c.getSolde());
			db.getPstm().setString(6, c.getClient().getCode());
			db.getPstm().setString(7, c.getTypeC());
			
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;

	}

	@Override
	public int deleteCompte(int id) {
		String sql = "delete from compte where idCpte = ?";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setInt(1, id);
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

	@Override
	public int updateCompte(Compte c) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Compte> listCompte() {
		db = new DB();
		String sql = "select * from compte";
		List<Compte> liste = new ArrayList<Compte>();
		try
		{
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			while(rs.next())
			{
				Compte cp = new Compte();
				cp.setIdCpte(rs.getInt(1));
				
				Agence ag = new Agence();
				ag.setNom(rs.getString(2));
				cp.setAgence(ag);

				cp.setNumCompte(rs.getString(3));
				cp.setCleRib(rs.getString(4));
				cp.setDateCreation(rs.getString(5));
				cp.setSolde(rs.getDouble(6));
				Client cl = new Client();
				cl.setCode(rs.getString(7));
				cp.setClient(cl);
				cp.setTypeC(rs.getString(8));
				
				liste.add(cp);
				
				
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return liste;
	}

	@Override
	public Compte getCompte(String numCompte) {
		Compte cp =null;
		String sql="select * from compte where numCompte=?";
		try
		{
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			if(rs.next()){
				cp=new Compte();
				cp.setIdCpte(rs.getInt(1));
				Agence ag = new Agence();
				ag.setIdA(rs.getInt(2));
				cp.setAgence(ag);
				cp.setNumCompte(rs.getString(3));
				cp.setCleRib(rs.getString(4));
				cp.setDateCreation(rs.getString(5));
				cp.setSolde(rs.getDouble(6));
				Client cl = new Client();
				cl.setCode(rs.getString(7));
				cp.setClient(cl);
				cp.setTypeC(rs.getString(8));
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(cp==null) throw new RuntimeException("Compte introuvable");
		return cp;
	}

	@Override
	public List<Compte> comptesparMC(String mc) {
		db = new DB();
		String sql = "select * from compte where numCompte like ?";
		List<Compte> comptes = new ArrayList<Compte>();
		try
		{
			pstm.setString(1, mc);
			db = new DB();
			db.initPrepareStatement(sql);
			rs = db.executeSelect();
			while(rs.next())
			{
				Compte c = new Compte();
				c.setIdCpte(rs.getInt("ID"));
				
				Agence ag = new Agence();
				ag.setNom(rs.getString("Agence"));
				c.setAgence(ag);

				c.setNumCompte(rs.getString("Numero"));
				c.setCleRib(rs.getString("CLE"));
				c.setDateCreation(rs.getString("Date"));
				c.setSolde(rs.getDouble("Solde"));
				Client cl = new Client();
				cl.setCode(rs.getString("Code"));
				c.setClient(cl);
				c.setTypeC(rs.getString("Type"));
				
				comptes.add(c);
				
				
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return comptes;

	

}
}
