package dao;

import java.util.List;

import beans.Operation;

public interface OperationDao {
	public int addOperation(Operation o);
	public int  deleteOperation(int id);
	public int updateOperation(Operation o);
	public List<Operation> listOperation();
	public 	Operation getOperationeById(int idO);
}
