package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import beans.CompteEpargne;

public class CompteEpargneImpl implements CompteEpargneDao{
	private int ok;
	private ResultSet rs;
	private DB db;
	private PreparedStatement pstm;

	@Override
	public int addCompteE(CompteEpargne ce) {
		String sql="insert into compteEpargne values(null,?)";
		try {
			db = new DB();
			db.initPrepareStatement(sql);
			db.getPstm().setString(1, ce.getFraisO());
			
			ok = db.executeMAJ();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ok;
	}

	@Override
	public int deleteCompteE(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateCompteE(CompteEpargne ce) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<CompteEpargne> listCompteE() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompteEpargne getCompteEById(int idCE) {
		// TODO Auto-generated method stub
		return null;
	}

}
