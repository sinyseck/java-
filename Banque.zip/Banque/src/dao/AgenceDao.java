package dao;

import java.util.List;

import beans.Agence;

public interface AgenceDao {
	public int addAgence(Agence a);
	public int  deleteAgence(int id);
	public int updateAgence(Agence a);
	public List<Agence> listAgence();
	public 	Agence getAgenceById(int idA);
	public Agence getAgenceById(String mc);
	


}
