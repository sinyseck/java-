package beans;

import java.sql.Date;

public class CompteEpargne  {
	private int idCE;
	private String fraisO;
	
	
	public CompteEpargne() {
		super();
		// TODO Auto-generated constructor stub
	}


	public CompteEpargne(int idCE, String fraisO) {
		super();
		this.idCE = idCE;
		this.fraisO = fraisO;
	}


	public int getIdCE() {
		return idCE;
	}


	public void setIdCE(int idCE) {
		this.idCE = idCE;
	}


	public String getFraisO() {
		return fraisO;
	}


	public void setFraisO(String fraisO) {
		this.fraisO = fraisO;
	}


	
}
