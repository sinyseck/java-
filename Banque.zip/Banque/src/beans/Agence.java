package beans;

public class Agence {
	private int idA;
	private String numAgence;
	private String nom;
	private String Adresse;
	
	public Agence() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Agence(int idA, String numAgence, String nom, String Adresse) {
		super();
		this.idA = idA;
		this.numAgence = numAgence;
		this.nom = nom;
		this.Adresse = Adresse;
	}

	public int getIdA() {
		return idA;
	}

	public void setIdA(int idA) {
		this.idA = idA;
	}

	public String getNumAgence() {
		return numAgence;
	}

	public void setNumAgence(String numAgence) {
		this.numAgence = numAgence;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getAdresse() {
		return Adresse;
	}

	public void setAdresse(String adresse) {
		Adresse = adresse;
	}
	
	
		
}
