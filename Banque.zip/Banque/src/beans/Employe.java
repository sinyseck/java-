package beans;

public class Employe {
	private int idE;
	private String code;
	private String nom;
	private String prenom;
	private String poste;
	private String tel;
	private Agence idA;
	
	
	public Employe() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Employe(int idE, String code, String nom, String prenom, String poste, String tel, Agence idA) {
		super();
		this.idE = idE;
		this.code = code;
		this.nom = nom;
		this.prenom = prenom;
		this.poste = poste;
		this.tel = tel;
		this.idA = idA;
	}


	public int getIdE() {
		return idE;
	}


	public void setIdE(int idE) {
		this.idE = idE;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getNom() {
		return nom;
	}
	public String getPrenom() {
		return prenom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}
	public void setPrenom(String prenom) {
		this.nom = prenom;
	}



	public String getPoste() {
		return poste;
	}


	public void setPoste(String poste) {
		this.poste = poste;
	}


	public String getTel() {
		return tel;
	}


	public void setTel(String tel) {
		this.tel = tel;
	}


	public Agence getIdA() {
		return idA;
	}


	public void setAgence(Agence idA) {
		this.idA = idA;
	}
	
	
	
	

}
