package beans;

import java.io.Serializable;
import java.sql.Date;
import java.util.Collection;

public class Compte implements Serializable{
	private int idCpte;
	private Agence agence;
	private String numCompte;
	private String cleRib;
	private String dateCreation;
	private double solde;
	private Client client;
	private String typeC;
	
	public Compte() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Compte(int idCpte, Agence agence, String numCompte, String cleRib, String dateCreation, double solde,
			Client client, String typeC) {
		super();
		this.idCpte = idCpte;
		this.agence = agence;
		this.numCompte = numCompte;
		this.cleRib = cleRib;
		this.dateCreation = dateCreation;
		this.solde = solde;
		this.client = client;
		this.typeC = typeC;
	}
	public int getIdCpte() {
		return idCpte;
	}
	public void setIdCpte(int idCpte) {
		this.idCpte = idCpte;
	}
	public Agence getAgence() {
		return agence;
	}
	public void setAgence(Agence Agence) {
		this.agence = agence;
	}
	public String getNumCompte() {
		return numCompte;
	}
	public void setNumCompte(String numCompte) {
		this.numCompte = numCompte;
	}
	public String getCleRib() {
		return cleRib;
	}
	public void setCleRib(String cleRib) {
		this.cleRib = cleRib;
	}
	public String getDateCreation() {
		return dateCreation;
	}
	public void setDateCreation(String dateCreation) {
		this.dateCreation = dateCreation;
	}
	public double getSolde() {
		return solde;
	}
	public void setSolde( double solde) {
		this.solde = solde;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public String getTypeC() {
		return typeC;
	}
	public void setTypeC(String typeC) {
		this.typeC = typeC;
	}
	
	
}
