package beans;

public class Operation {
	private int idO;
	private String numero;
	private String type;
	private String dateOperation;
	private double montant;
	private Compte compte;
	
	public Operation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getIdO() {
		return idO;
	}

	public void setIdO(int idO) {
		this.idO = idO;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDateOperation() {
		return dateOperation;
	}

	public void setDateOperation(String dateOperation) {
		this.dateOperation = dateOperation;
	}

	public double getMontant() {
		return montant;
	}

	public void setMontant(double montant) {
		this.montant = montant;
	}

	public Compte getCompte() {
		return compte;
	}

	public void setCompte(Compte compte) {
		this.compte = compte;
	}

	public Operation(int idO, String numero, String type, String dateOperation, double montant, Compte compte) {
		super();
		this.idO = idO;
		this.numero = numero;
		this.type = type;
		this.dateOperation = dateOperation;
		this.montant = montant;
		this.compte = compte;
	}
	
	

}
