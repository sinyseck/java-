package beans;

public class Client {
	private int id;
	private String code;
	private String nom;
	private String prenom;
	private String dateNais;
	private String ville;
	private String pays;
	private String mail;
	private String telephone;
	private String profession;
	private String travailleur;
	private String salaire;
	private String employeur;
	private String motDePasse;
	private String solde;
	private String agence;
	
	

	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Client(int id, String code, String nom, String prenom, String dateNais, String ville, String pays,
			String mail, String telephone, String profession, String travailleur, String salaire, String employeur,
			String motDePasse, String solde, String agence) {
		super();
		this.id = id;
		this.code = code;
		this.nom = nom;
		this.prenom = prenom;
		this.dateNais = dateNais;
		this.ville = ville;
		this.pays = pays;
		this.mail = mail;
		this.telephone = telephone;
		this.profession = profession;
		this.travailleur = travailleur;
		this.salaire = salaire;
		this.employeur = employeur;
		this.motDePasse = motDePasse;
		this.solde = solde;
		this.agence = agence;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getDateNais() {
		return dateNais;
	}

	public void setDateNais(String dateNais) {
		this.dateNais = dateNais;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public String getPays() {
		return pays;
	}

	public void setPays(String pays) {
		this.pays = pays;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public String getTravailleur() {
		return travailleur;
	}

	public void setTravailleur(String travailleur) {
		this.travailleur = travailleur;
	}

	public String getSalaire() {
		return salaire;
	}

	public void setSalaire(String salaire) {
		this.salaire = salaire;
	}

	public String getEmployeur() {
		return employeur;
	}

	public void setEmployeur(String employeur) {
		this.employeur = employeur;
	}

	public String getAgence() {
		return agence;
	}

	public void setAgence(String agence) {
		this.agence = agence;
	}

	public String getMotDePasse() {
		return motDePasse;
	}

	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}

	public String getSolde() {
		return solde;
	}

	public void setSolde(String solde) {
		this.solde = solde;
	}
	
	
	
}
